// This file can be used for any application-wide constants
// Add any other constants you may need

export const TOKEN_EXPIRATION_TIME = 3600; // 1 hour in seconds
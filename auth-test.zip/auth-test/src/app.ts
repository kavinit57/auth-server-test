import express from 'express';

const app = express();

// Middleware and other app-level settings go here

export default app;